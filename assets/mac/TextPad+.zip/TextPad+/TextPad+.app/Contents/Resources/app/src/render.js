"use strict";
/**
 * Author @Nikhil Notse - copyright protected
 * The software is free to use but no modification allowed
 */
const buttons = document.querySelectorAll("button");
const popUp = document.querySelector(".pop-up");
const firstBtn = document.querySelector(".first-btn");
const Toolbar = document.querySelector(".toolbar");
const moreTools = document.querySelector(".more-tools");
const defaultTools = document.querySelector(".default-tools");
const nextBox = document.querySelector(".next-box");
const Back = document.querySelector(".back");
const NotePad = document.querySelector(".writing-pad");
const Toggle = document.querySelector(".toggle");
const ToggleIcon = document.querySelector(".fa-chevron-left");
const BodyEle = document.querySelector("body");
const Alert = document.querySelector(".alert");
const menuBtn = document.querySelector(".menu");
const element = document.getElementById("content");
const tool = document.querySelector(".default-tools");
const tools = document.querySelectorAll(".toolbar-btn");

let i = 10;
let isExpand = false;
let code = false;
let isBlock = true;

document.addEventListener("DOMContentLoaded", () => {
  getOs();
});

window.addEventListener("resize", setToolbar, true);

function setToolbar(event) {
  window.innerHeight - tool.clientHeight >= 60 && window.innerHeight < 560
    ? (isExpand = true)
    : "";
  !moreTools.classList.contains("block")
    ? moreTools.classList.add("block")
    : "";
  if (window.innerHeight - tool.clientHeight < 60) {
    i < 11 && i > 3 ? nextBox.insertAdjacentElement("beforeend", tools[i]) : "";
    i > 3 ? i-- : "";
  } else if (window.innerHeight - tool.clientHeight >= 120 && isExpand) {
    i < 11
      ? defaultTools.insertAdjacentElement("beforeend", tools[i])
      : (i = 10);
    i++;
    defaultTools.lastChild.getAttribute("data-edit") === "CreateLink"
      ? moreTools.classList.remove("block")
      : "";
  }
}

function getOs() {
  var userAgent = navigator.userAgent || navigator.vendor || window.opera;
  if (
    /android/i.test(userAgent) ||
    /iphone/i.test(userAgent) ||
    /ipad/i.test(userAgent)
  ) {
    setViewport();
  }
}

// https://stackoverflow.com/questions/31817297/get-constant-browser-height-and-width
function setViewport() {
  Toolbar.style.height = window.innerHeight + "px";
  Alert.style.width = window.innerWidth / 1.2 + "px";
  Alert.style.height = window.innerheight / 2 + "px";
}

NotePad.addEventListener("keyup", characterCount);

moreTools.addEventListener("click", () => {
  if (nextBox.children.length) {
    ToolBox("none", "block");
    moreTools.classList.toggle("block");
    Back.classList.add("block");
  } else {
    alert(
      "Note : Tools are available on the sidebar, Decrease The height to Hide tools"
    );
  }
});

Back.addEventListener("click", () => {
  ToolBox("block", "none");
  moreTools.classList.toggle("block");
  Back.classList.remove("block");
});

Toggle.addEventListener("click", () => {
  Toolbar.classList.toggle("toggle-open");
  ToggleIcon.classList.toggle("rotate-icon");
});

function ToolBox(val1, val2) {
  defaultTools.style.display = val1;
  nextBox.style.display = val2;
}

firstBtn.addEventListener("click", () => {
  popUp.classList.toggle("open");
  firstBtn.classList.toggle("active");
});

function set() {
  NotePad.classList.toggle("rtl");
}

popUp.addEventListener("click", () => {
  popUp.classList.toggle("open");
  firstBtn.classList.toggle("active");
});

for (let i = 0; i < buttons.length; i++) {
  buttons[i].addEventListener("click", () => {
    let edit = buttons[i].getAttribute("data-edit");

    if (
      edit === "h1" ||
      // edit === "blockquote" ||
      edit === "h5" ||
      edit === "h2" ||
      edit === "p" ||
      edit === "p"
    ) {
      document.execCommand("formatBlock", false, edit);
    } else if (edit === "showCode") {
      if (code) {
        NotePad.innerHTML = NotePad.textContent;
        code = false;
      } else {
        NotePad.textContent = NotePad.innerHTML;
        code = true;
      }
    } else if (edit === "CreateLink") {
      let url = prompt("Enter a link");
      !!url ? document.execCommand(edit, false, url) : console.log(url);
    } else if (edit === "InsertImage") {
      element.focus();
      let url = prompt("Enter a link");
      if (!!url) {
        document.execCommand(edit, false, url);
      }
    } else if (edit === "blockquote") {
      if (isBlock) {
        document.execCommand("formatBlock", false, edit);
        isBlock = false;
      } else {
        document.execCommand("formatBlock", false, "p");
        isBlock = true;
      }
    } else {
      document.execCommand(edit, false, null);
      element.focus();
    }
  });
}

function menu() {
  let menuIcon = document.querySelector(".menu-icon");

  menuBtn.classList.toggle("open");
  menuIcon.classList.toggle("gear");
}

function DialogBox(cmd) {
  Alert.classList.toggle("alert-open");
  menuBtn.classList.remove("open");

  if (cmd === "txt") {
    downloadText(cmd);
  } else if (cmd === "html") {
    downloadText(cmd);
  } else if (cmd === "md") {
    downloadText(cmd);
  }
}

function characterCount() {
  const Characters = document.querySelector(".characters");
  // const Words = document.querySelector(".words");
  // Words.textContent = `Words : ${
  //   NotePad.textContent.trim().split(" ").toString() === "" || undefined
  //     ? 0
  //     : NotePad.textContent.trim().split(" ").length

  // }`;
  Characters.textContent = `Characters : ${NotePad.textContent.trim().length}`;
}

function downloadText(event) {
  let Content = document.getElementById("content");
  let anchor = document.body.appendChild(document.createElement("a"));

  if (event === "txt") {
    anchor.download = "file.txt";
    anchor.href = "data:text/plain;charset=utf-8," + Content.textContent;
    anchor.click();
  } else if (event === "html") {
    anchor.download = "file.html";
    anchor.href =
      "data:text/html;charset=utf-8," + encodeURIComponent(Content.innerHTML);
    anchor.click();
  } else {
    let turndownService = new TurndownService({
      headingStyle: "atx",
      codeBlockStyle: "fenced",
      emDelimiter: "*",
    });
    let markdown = turndownService.turndown(
      document.getElementById("content").innerHTML
    );
    anchor.download = "file.md";
    anchor.href =
      "data:text/plain;charset=utf-8," + encodeURIComponent(markdown);
    anchor.click();
  }
}
function Newfile() {
  if (!!confirm("Are You sure")) {
    NotePad.textContent = "Start Typing...";
    characterCount();
  }
}
function printPage() {
  let print_page = window.open();
  print_page.document.write(NotePad.innerHTML);
  print_page.document.close();
  print_page.focus();
  print_page.print();
  print_page.close();
}
function fontSize(ev) {
  let Content = document.getElementById("content");
  Content.style.fontSize = ev.value + "px";
}
document.addEventListener("keydown", (ev) => {
  if (ev.metaKey && ev.key === "v") {
    element.addEventListener("paste", onPaste);
  }
});
element.addEventListener("paste", onPaste);
function onPaste(ev) {
  ev.preventDefault();
  let paste = (ev.clipboardData || window.clipboardData).getData("text");
  paste = paste;
  const selection = document.getSelection();
  if (!selection.rangeCount) return;
  selection.deleteFromDocument();
  let node = document.createTextNode(paste);
  selection.getRangeAt(0).insertNode(node);
}
/**
 * Author @Nikhil Notse - copyright protected
 * The software is free to use but no modification allowed
 */
